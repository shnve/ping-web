import{b as a}from"./chunk-D6NSYICF.js";import"./chunk-H4HD6HND.js";import"./chunk-JSJMT55G.js";import"./chunk-FYVPAH6O.js";import"./chunk-EMXJSK3V.js";import"./chunk-N3VKLXFR.js";export{a as StaticLogoModule};
//# sourceMappingURL=chunk-KR3ZJODP.js.map
