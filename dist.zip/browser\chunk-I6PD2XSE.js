import{a}from"./chunk-JVVN44SX.js";import"./chunk-2XTH2UUJ.js";import"./chunk-YK4SR3CL.js";import"./chunk-H4HD6HND.js";import"./chunk-JSJMT55G.js";import"./chunk-FYVPAH6O.js";import"./chunk-EMXJSK3V.js";import"./chunk-N3VKLXFR.js";export{a as StaticSectionModule};
//# sourceMappingURL=chunk-I6PD2XSE.js.map
