import{a as e}from"./chunk-VHJ6FQ7J.js";import{a as r}from"./chunk-NAIDPIRV.js";import"./chunk-N3VKLXFR.js";var o=class extends r{decodeBlock(t){return e(new Uint8Array(t)).buffer}};export{o as default};
//# sourceMappingURL=chunk-ATBAX5VZ.js.map
