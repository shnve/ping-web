import{a as e}from"./chunk-NAIDPIRV.js";import"./chunk-N3VKLXFR.js";var o=class extends e{decodeBlock(r){return r}};export{o as default};
//# sourceMappingURL=chunk-I4LCHGPB.js.map
